export interface Creator {
  id: string;
  name: string;
  subscribers: string;
  avatar: string;
  specialty: string;
  profileUrl?: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: "long-form" | "shorts" | "thumbnails" | "podcasts" | "management";
  bannerUrl: string;
  videoUrl?: string;
  stats?: string;
  ctr?: string;
  creator: {
    name: string;
    avatar: string;
    subscribers: string;
  };
}

export interface ServiceType {
  id: string;
  title: string;
  description: string;
  icon: string;
  ctrBoost?: string;
  basePrice: number;
}
