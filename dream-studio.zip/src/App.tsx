/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import CreatorSlider from "./components/CreatorSlider";
import ServicesList from "./components/ServicesList";
import PortfolioShowcase from "./components/PortfolioShowcase";
import StatsCounter from "./components/StatsCounter";
import GetInTouchForm from "./components/GetInTouchForm";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="w-full relative bg-white selection:bg-brand-red selection:text-white">
      {/* Header navbar layout */}
      <Header />

      {/* Main Container wrapping full aesthetic bento design system */}
      <div className="bg-grid-pattern min-h-screen relative">
        {/* Dynamic typographical hero layout */}
        <Hero />

        {/* Brand slider loop for partnering creators */}
        <CreatorSlider />

        {/* Service grid panels detailing design offerings */}
        <ServicesList />

        {/* Comprehensive work collection showcase tab-grid with embeds */}
        <PortfolioShowcase />

        {/* High performance scale dashboard specs */}
        <StatsCounter />

        {/* Dynamic customer application quote selector setup */}
        <GetInTouchForm />

        {/* Modern clean brand information footer */}
        <Footer />
      </div>
    </div>
  );
}
