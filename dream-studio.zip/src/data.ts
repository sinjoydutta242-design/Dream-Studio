import { Creator, PortfolioItem, ServiceType } from "./types";

export const SERVICES: ServiceType[] = [
  {
    id: "long-form",
    title: "Long Form Video Editing",
    description: "Highly engaging storytelling edits that maximize watch-time, retain viewers' attention span, and turn casual clickers into loyal subscribers.",
    icon: "Video",
    ctrBoost: "High retention edits",
    basePrice: 104
  },
  {
    id: "shorts",
    title: "Shorts / Reels Video Editing",
    description: "Nail your YouTube Shorts, Instagram Reels, and TikToks with snappy pacing, custom text captions, progress bars, and highly addictive loops.",
    icon: "Zap",
    ctrBoost: "Up to 5x higher virality",
    basePrice: 52
  },
  {
    id: "thumbnails",
    title: "Thumbnail Designing",
    description: "High-click rate designs featuring custom 3D-lit visual compositing and clean typography structure. CTR boosts guaranteed.",
    icon: "Image",
    ctrBoost: "Up to 78% higher CTR",
    basePrice: 49
  },
  {
    id: "podcasts",
    title: "Podcast Video Editing",
    description: "Multi-camera switching edits with advanced audio enhancement, filler-word pruning, and custom highlight reels to grow audio platforms visually.",
    icon: "Mic",
    ctrBoost: "Perfect stereo mixing",
    basePrice: 199
  },
  {
    id: "management",
    title: "YT Channel Management",
    description: "End-to-end growth strategy from descriptive indexing, detailed tag setups, custom smart schedule publishing, and analytics teardowns.",
    icon: "BarChart",
    ctrBoost: "+120% organic traffic",
    basePrice: 399
  }
];

export const CREATORS: Creator[] = [
  {
    id: "value-educator",
    name: "Value Educator",
    subscribers: "157K Subscribers",
    avatar: "https://yt3.googleusercontent.com/ytc/AIdro_knyy1IQqE-EaisDjw6RAc4FxXhK7t8lhvs4cYUQBOnRT0=s176-c-k-c0x00ffffff-no-rj-mo",
    specialty: "Research analyst",
  },
  
  
  
];

export const PORTFOLIO_PROJECTS: PortfolioItem[] = [
  {
    id: "proj-1",
    title: "Hidden Small Cap Stock for Defence and AI",
    category: "long-form",
    bannerUrl: "https://valueeducator.com/uploads/articles/WhatsApp%20Image%202026-05-14%20at%2013.00.52.jpeg?v=1780032315",
    videoUrl: "https://youtu.be/e3jP79WFIwQ?si=CBuDsiK8_EuvXej5",
    stats: "2.4M Views • Over 85% Retention",
    creator: {
      name: "Value Educator",
      subscribers: "157K",
      avatar: "https://yt3.googleusercontent.com/ytc/AIdro_knyy1IQqE-EaisDjw6RAc4FxXhK7t8lhvs4cYUQBOnRT0=s176-c-k-c0x00ffffff-no-rj-mo"
    }
  },
  {
    id: "proj-2",
    title: "Hidden Small cap Defence company ",
    category: "long-form",
    bannerUrl: "https://i.ytimg.com/vi/80AmZboN7Kw/hqdefault.jpg",
    videoUrl: "https://youtu.be/C3phFZDFr18?si=EBaIoeqFPty3cbwE",
    stats: "1.2M Views • 20% Subs Conversion Ratio",
    creator: {
      name: "Value Educator",
      subscribers: "157k",
      avatar: "https://yt3.googleusercontent.com/ytc/AIdro_knyy1IQqE-EaisDjw6RAc4FxXhK7t8lhvs4cYUQBOnRT0=s176-c-k-c0x00ffffff-no-rj-mo"
    }
  },
  {
    id: "proj-3",
    title: "Strong Small Cap Power Stock | Proxy For Data Centre ?",
    category: "long-form",
    bannerUrl: "https://i.ytimg.com/vi/H_QBb06d5xk/hqdefault.jpg?v=69f4b87d",
    videoUrl: "https://youtu.be/80AmZboN7Kw?si=OACPsuL_tql4PqE4",
    stats: "850K Views • +30% CTR Spike",
    creator: {
      name: "Value Educator",
      subscribers: "157K",
      avatar: "https://yt3.googleusercontent.com/ytc/AIdro_knyy1IQqE-EaisDjw6RAc4FxXhK7t8lhvs4cYUQBOnRT0=s176-c-k-c0x00ffffff-no-rj-mo"
    }
  },
  {
    id: "proj-4",
    title: "Hidden Monopoly Small Cap Stock for Data Centres ?",
    category: "long-form",
    bannerUrl: "https://i.ytimg.com/vi/80AmZboN7Kw/hqdefault.jpg",
    videoUrl: "https://youtu.be/boSzMc7HMRs?si=AbYJa2MiXJQqPCSS",
    stats: "92K Likes • 2.6M Impression Funnel",
    creator: {
      name: "Value Educator",
      subscribers: "157K",
      avatar: "https://yt3.googleusercontent.com/ytc/AIdro_knyy1IQqE-EaisDjw6RAc4FxXhK7t8lhvs4cYUQBOnRT0=s176-c-k-c0x00ffffff-no-rj-mo"
    }
  },
 
  
  {
    id: "short-1",
    title: "Why Are Transformers Stocks Rallying ??",
    category: "shorts",
    bannerUrl: "https://substack-post-media.s3.amazonaws.com/public/images/460d11d7-f6e0-477e-bc57-50bd1a0aca1d_1280x376.png",
    videoUrl: "https://youtube.com/shorts/VxUnbVBUuDA?si=GxIT6Ml3F-3HxmBF",
    stats: "2.4M Views • Real-time viral text style",
    creator: {
      name: "Value Educator",
      subscribers: "157K",
      avatar: "https://yt3.googleusercontent.com/ytc/AIdro_knyy1IQqE-EaisDjw6RAc4FxXhK7t8lhvs4cYUQBOnRT0=s176-c-k-c0x00ffffff-no-rj-mo"
    }
  },
  {
    id: "short-2",
    title: "Hidden Power Stock that moves Electricity ",
    category: "shorts",
    bannerUrl: "https://substack-post-media.s3.amazonaws.com/public/images/460d11d7-f6e0-477e-bc57-50bd1a0aca1d_1280x376.png",
    videoUrl: "https://youtube.com/shorts/dOQWZOELees?si=9_KmftbjbFpKF7Ur",
    stats: "1.1M loops • Interactive caption tracking",
    creator: {
      name: "Value Educator",
      subscribers: "157K",
      avatar: "https://yt3.googleusercontent.com/ytc/AIdro_knyy1IQqE-EaisDjw6RAc4FxXhK7t8lhvs4cYUQBOnRT0=s176-c-k-c0x00ffffff-no-rj-mo"
    }
  }
];
