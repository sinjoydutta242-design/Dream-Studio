import React from "react";
import { Users, Eye, TrendingUp, Sparkles } from "lucide-react";

export default function StatsCounter() {
  return (
    <section className="py-20 bg-white border-b border-gray-100" id="stats">
      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        {/* Left Side: Copy */}
        <div className="lg:col-span-5 flex flex-col items-start gap-4">
          <span className="text-xs font-bold text-brand-red uppercase tracking-widest font-space inline-flex items-center gap-1.5 px-3 py-1 bg-brand-red/5 rounded-full">
            <Sparkles className="w-3 h-3" /> TRACK RECORD
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-black text-brand-blue tracking-tight leading-tight">
            Impact That Speaks For Itself
          </h2>
          <p className="text-gray-400 font-sans text-sm leading-relaxed">
            Creators worldwide trust Dream Studio to optimize their click rates and retain attention spans. We align editing setups explicitly to each channel's voice—whether it is reaction videos, technical guides, or cinematic storytelling diaries.
          </p>
          <div className="mt-2 text-xs font-semibold text-brand-blue/60 flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
            Currently managing post-production streams for 5 channels
          </div>
        </div>

        {/* Right Side: Grid Numbers */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-6 w-full">
          {/* Card 1 */}
          <div className="bg-zinc-900 border border-white/5 p-8 rounded-3xl text-left flex flex-col justify-between hover:border-brand-red/25 transition-card shadow-sm">
            <div className="bg-zinc-950 p-3 rounded-2xl w-max text-[#CCFF00] border border-white/5 mb-6">
              <Users className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="font-display font-black text-4xl sm:text-5xl text-white tracking-tight">
                100+
              </div>
              <p className="text-xs uppercase font-space font-extrabold text-slate-500 tracking-wider mt-2">
                Creators Served
              </p>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-zinc-900 border border-white/5 p-8 rounded-3xl text-left flex flex-col justify-between hover:border-brand-red/25 transition-card shadow-sm">
            <div className="bg-zinc-950 p-3 rounded-2xl w-max text-[#CCFF00] border border-white/5 mb-6">
              <TrendingUp className="w-6 h-6 stroke-[2.5] text-brand-red" />
            </div>
            <div>
              <div className="font-display font-black text-4xl sm:text-5xl text-white tracking-tight">
                5M+
              </div>
              <p className="text-xs uppercase font-space font-extrabold text-slate-500 tracking-wider mt-2">
                Subs Gained
              </p>
            </div>
          </div>

          {/* Card 3 - Core Neon star card */}
          <div className="bg-brand-red text-[#0A0A0A] p-8 rounded-3xl text-left flex flex-col justify-between hover:scale-102 transition-card shadow-lg shadow-brand-red/5">
            <div className="bg-black/10 p-3 rounded-2xl w-max text-[#0A0A0A] border border-black/5 mb-6">
              <Eye className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="font-display font-black text-4xl sm:text-5xl text-[#0A0A0A] tracking-tighter leading-none">
                3.4B
              </div>
              <p className="text-xs uppercase font-space font-extrabold text-[#0A0A0A]/70 tracking-wider mt-2">
                Total Views
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
