import React, { useRef } from "react";
import { ChevronLeft, ChevronRight, Users, Play, Radio } from "lucide-react";
import { CREATORS } from "../data";

export default function CreatorSlider() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -320, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 320, behavior: "smooth" });
    }
  };

  return (
    <section className="bg-brand-bg-light py-16 border-b border-gray-100" id="creators">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Title Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <span className="text-xs font-bold text-brand-red uppercase tracking-widest font-space inline-block mb-2">
              Partnership Success
            </span>
            <h2 className="font-display text-4xl font-extrabold text-brand-blue tracking-tight">
              Creators We've Propelled Forward
            </h2>
            <p className="text-gray-400 text-sm font-sans mt-2 max-w-xl">
              From large informative hubs like <strong>Value Educator</strong> to passionate smaller niches. We optimize retention layout so creators can scale smoothly.
            </p>
          </div>

          <div className="flex gap-2 mt-6 md:mt-0 select-none">
            <button
              onClick={scrollLeft}
              className="p-3 rounded-full bg-zinc-900 border border-white/10 hover:border-brand-red text-white transition-colors cursor-pointer"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={scrollRight}
              className="p-3 rounded-full bg-zinc-900 border border-white/10 hover:border-brand-red text-white transition-colors cursor-pointer"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Sliding Row Container */}
        <div 
          ref={scrollContainerRef}
          className="flex gap-6 overflow-x-auto pb-6 pt-2 no-scrollbar"
          style={{ scrollSnapType: "x mandatory" }}
        >
          {CREATORS.map((creator) => (
            <div
              key={creator.id}
              className="flex-shrink-0 w-80 bg-zinc-900 border border-white/5 p-6 rounded-3xl shadow-md hover:shadow-xl hover:border-brand-red/20 transition-card flex flex-col justify-between"
              style={{ scrollSnapAlign: "start" }}
            >
              <div>
                {/* Channel Meta */}
                <div className="flex items-center gap-4 mb-5">
                  <img
                    src={creator.avatar}
                    alt={creator.name}
                    className="w-16 h-16 rounded-full object-cover ring-2 ring-white/10"
                  />
                  <div>
                    <h3 className="font-display font-extrabold text-white text-base leading-tight">
                      {creator.name}
                    </h3>
                    <span className="inline-flex items-center gap-1 text-xs font-space font-semibold text-brand-red bg-brand-red/10 px-2 py-0.5 rounded-full mt-1">
                      <Radio className="w-3 h-3" /> {creator.subscribers}
                    </span>
                  </div>
                </div>

                {/* Tags & Description */}
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-space block mb-1">
                    Speciality Category
                  </span>
                  <p className="text-slate-300 font-medium text-sm leading-snug">
                    {creator.specialty}
                  </p>
                </div>
              </div>

              {/* Verified Badge */}
              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                <span className="text-xs font-bold font-space text-brand-red flex items-center gap-1.5 bg-brand-red/10 px-2.5 py-1 rounded-full">
                  <span className="h-1.5 w-1.5 rounded-full bg-brand-red animate-pulse"></span> Partner
                </span>
                <span className="text-xs font-space font-medium text-slate-500">
                  Full post-prod
                </span>
              </div>
            </div>
          ))}

          {/* Plus smaller creators promo card */}
          <div
            className="flex-shrink-0 w-80 bg-zinc-950 text-white p-6 rounded-3xl shadow-lg flex flex-col justify-between border border-brand-red/25"
            style={{ scrollSnapAlign: "start" }}
          >
            <div>
              <div className="w-12 h-12 bg-brand-red/10 rounded-2xl flex items-center justify-center text-xl mb-4">
                🚀
              </div>
              <h3 className="font-display font-black text-xl text-white leading-snug mb-3 text-stroke-neon uppercase">
                And 12+ Small Creators Scaled Up!
              </h3>
              <p className="text-slate-300 text-xs leading-relaxed font-light">
                Whether you are starting out at 1,000 subscribers or looking to hit your first 100k, we adjust our pacing patterns to suit your growth trajectory.
              </p>
            </div>
            
            <div className="pt-4 border-t border-white/10">
              <p className="text-[10px] font-space text-slate-500 uppercase tracking-widest">
                Dream Studio Promise
              </p>
              <p className="text-xs font-semibold text-brand-red mt-1">
                Zero retention drop guarantees.
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
