import React, { useState } from "react";
import { Send, CheckCircle2, RotateCcw, HelpCircle } from "lucide-react";
import { SERVICES } from "../data";

export default function GetInTouchForm() {
  // Form values
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [channelLink, setChannelLink] = useState("");
  const [projectBrief, setProjectBrief] = useState("");
  
  // Selected Services
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  
  // Submission Status
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formError, setFormError] = useState("");

  const toggleService = (srvId: string) => {
    setSelectedServices(prev => 
      prev.includes(srvId)
        ? prev.filter(id => id !== srvId)
        : [...prev, srvId]
    );
  };

  // Calculate real-time project estimate
  const currentEstimate = selectedServices.reduce((sum, srvId) => {
    const srv = SERVICES.find(s => s.id === srvId);
    return sum + (srv ? srv.basePrice : 0);
  }, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple Validation
    if (!clientName.trim()) {
      setFormError("Please enter your name or company name.");
      return;
    }
    if (!clientEmail.trim() || !clientEmail.includes("@")) {
      setFormError("Please enter a valid email address.");
      return;
    }
    if (!channelLink.trim()) {
      setFormError("Please provide your YouTube channel link.");
      return;
    }
    if (selectedServices.length === 0) {
      setFormError("Please select at least one service you need.");
      return;
    }

    setFormError("");
    setIsSubmitted(true);
  };

  const handleReset = () => {
    setClientName("");
    setClientEmail("");
    setChannelLink("");
    setProjectBrief("");
    setSelectedServices([]);
    setIsSubmitted(false);
  };

  return (
    <section className="py-20 bg-[#0A0A0A]" id="get-started">
      <div className="max-w-4xl mx-auto px-4 md:px-8">
        
        {/* Card Frame wrapping form */}
        <div className="bg-zinc-900 border-2 border-white/5 rounded-[32px] p-6 sm:p-12 shadow-2xl relative overflow-hidden">
          {/* Crimson accent ribbon */}
          <div className="absolute left-0 right-0 bottom-0 h-2 bg-brand-red" />

          {/* Heading */}
          <div className="mb-10 text-left">
            <span className="text-xs font-bold text-brand-red uppercase tracking-widest font-space inline-block mb-2">
              GET STARTED NOW
            </span>
            <h2 className="font-display text-4xl sm:text-5xl font-black text-white tracking-tight leading-none">
              Tell us what <span className="text-brand-red">you need</span>
            </h2>
            <p className="text-slate-400 font-sans text-sm mt-3">
              Dream Studio customized creative application. Build your package dynamically to see your estimated baseline budget immediately.
            </p>
          </div>

          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-8">
              
              {/* Error Callout */}
              {formError && (
                <div className="bg-brand-red/10 text-brand-red border border-brand-red/15 p-4 rounded-2xl text-sm font-semibold">
                  ⚠️ {formError}
                </div>
              )}

              {/* Service Selection Interactive Pills */}
              <div className="space-y-4 text-left">
                <label className="block text-white font-display font-bold text-lg mb-2">
                  1. Choose Services to Bundle <span className="text-brand-red">*</span>
                </label>
                
                <div className="flex flex-wrap gap-3">
                  {SERVICES.map((srv) => {
                    const isSelected = selectedServices.includes(srv.id);
                    return (
                      <button
                        type="button"
                        key={srv.id}
                        onClick={() => toggleService(srv.id)}
                        className={`px-4 py-2.5 rounded-full text-xs sm:text-sm font-semibold font-space tracking-wide transition-all border cursor-pointer ${
                          isSelected
                            ? "bg-brand-red text-[#0A0A0A] border-brand-red shadow-lg shadow-brand-red/15 font-extrabold"
                            : "bg-transparent text-[#F5F5F5] border-white/10 hover:text-brand-red hover:border-brand-red"
                        }`}
                      >
                        {srv.title} (${srv.basePrice})
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Text Fields Grid Input - Underlined visual design matched */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
                
                {/* Field 1: Name */}
                <div className="flex flex-col gap-2">
                  <label htmlFor="clientName" className="font-display font-bold text-white text-sm">
                    Your Name<span className="text-brand-red">*</span>
                  </label>
                  <input
                    id="clientName"
                    type="text"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="e.g. Dreamer Channel Studio"
                    className="w-full bg-transparent border-0 border-b border-white/10 focus:border-brand-red font-sans text-white py-2.5 focus:outline-none transition-colors placeholder:text-slate-600"
                    required
                  />
                </div>

                {/* Field 2: Email */}
                <div className="flex flex-col gap-2">
                  <label htmlFor="clientEmail" className="font-display font-bold text-white text-sm">
                    Your Email <span className="text-brand-red">*</span>
                  </label>
                  <input
                    id="clientEmail"
                    type="email"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    placeholder="e.g. you@creatorpartners.com"
                    className="w-full bg-transparent border-0 border-b border-white/10 focus:border-brand-red font-sans text-white py-2.5 focus:outline-none transition-colors placeholder:text-slate-600"
                    required
                  />
                </div>

                {/* Field 3: Channel Link */}
                <div className="flex flex-col gap-2 md:col-span-2">
                  <label htmlFor="channelLink" className="font-display font-bold text-white text-sm">
                    YouTube Channel Link<span className="text-brand-red">*</span>
                  </label>
                  <input
                    id="channelLink"
                    type="text"
                    value={channelLink}
                    onChange={(e) => setChannelLink(e.target.value)}
                    placeholder="e.g. youtube.com/@value-educator"
                    className="w-full bg-transparent border-0 border-b border-white/10 focus:border-brand-red font-sans text-white py-2.5 focus:outline-none transition-colors placeholder:text-slate-600"
                    required
                  />
                </div>

                {/* Field 4: About Brief */}
                <div className="flex flex-col gap-2 md:col-span-2">
                  <label htmlFor="projectBrief" className="font-display font-bold text-white text-sm">
                    About Your Project 
                  </label>
                  <textarea
                    id="projectBrief"
                    value={projectBrief}
                    onChange={(e) => setProjectBrief(e.target.value)}
                    placeholder="Describe your uploads schedule, editing style presets you love..."
                    rows={1}
                    className="w-full bg-transparent border-0 border-b border-white/10 focus:border-brand-red font-sans text-white py-2.5 resize-y focus:outline-none transition-colors min-h-[42px] placeholder:text-slate-600"
                  />
                </div>

              </div>

              {/* Calculator Summary Widget & Submit */}
              <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-6">
                
                {/* Dynamically Calced Baseline Package */}
                <div className="text-left bg-zinc-950 p-4 px-6 rounded-2xl border border-white/5 max-w-xs flex-grow">
                  <span className="text-[10px] uppercase font-bold text-slate-500 font-space tracking-widest block font-medium">
                    Calculated Baseline Package
                  </span>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="font-display font-black text-3xl text-brand-red">
                      ${currentEstimate}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-400">/ estimated bill</span>
                  </div>
                </div>

                {/* Action Trigger button */}
                <button
                  type="submit"
                  className="bg-brand-red text-[#0A0A0A] text-base font-bold font-display px-10 py-4.5 rounded-full hover:bg-brand-red-hover hover:translate-y-[-2px] hover:scale-[1.01] transition-all shadow-lg shadow-brand-red/25 flex items-center justify-center gap-2 group cursor-pointer"
                >
                  Send Application 
                  <Send className="w-4 h-4 text-[#0A0A0A] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </button>

              </div>
              
            </form>
          ) : (
            // Success Breakdown State
            <div className="text-center py-10 flex flex-col items-center gap-6">
              <div className="w-20 h-20 rounded-full bg-brand-red/10 text-brand-red flex items-center justify-center animate-bounce border border-brand-red/20">
                <CheckCircle2 className="w-12 h-12 stroke-[2.5]" />
              </div>

              <div>
                <h3 className="font-display font-black text-3xl text-white tracking-tight">
                  Application Logged Smoothly!
                </h3>
                <p className="text-slate-400 font-sans text-sm mt-2 max-w-md mx-auto font-light">
                  Thank you for submitting, <strong>{clientName}</strong>! Our growth coordinators at <strong>Dream Studio</strong> will review your channel and get back to you via <strong>{clientEmail}</strong> in under 24 hours.
                </p>
              </div>

              {/* Dynamic Package Overview Breakdown Cards */}
              <div className="bg-zinc-950 border border-white/5 rounded-3xl p-6 w-full max-w-md text-left mt-4 space-y-3 font-space">
                <h4 className="text-white font-bold text-xs uppercase tracking-wide">
                  Your Bundled Packages
                </h4>
                
                <div className="space-y-2">
                  {selectedServices.map(srvId => {
                    const srv = SERVICES.find(s => s.id === srvId);
                    return (
                      <div key={srvId} className="flex justify-between items-center text-sm font-medium">
                        <span className="text-slate-300">{srv?.title}</span>
                        <span className="text-brand-red font-bold">${srv?.basePrice}</span>
                      </div>
                    );
                  })}
                </div>

                <div className="pt-3 border-t border-white/15 flex justify-between items-center font-display font-extrabold text-base">
                  <span className="text-white">Total Package:</span>
                  <span className="text-[#CCFF00] font-black">${currentEstimate}/mo</span>
                </div>
              </div>

              <button
                onClick={handleReset}
                className="mt-6 inline-flex items-center gap-2 text-xs font-bold font-space text-slate-500 hover:text-brand-red transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Submit Another Application
              </button>
            </div>
          )}

        </div>

      </div>
    </section>
  );
}
