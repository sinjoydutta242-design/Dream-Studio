import React, { useState } from "react";
import { Play, TrendingUp, X, Award, Eye, FileText, ChevronRight } from "lucide-react";
import { PORTFOLIO_PROJECTS } from "../data";

export default function PortfolioShowcase() {
  const [activeTab, setActiveTab] = useState<"all" | "long-form" | "shorts" | "thumbnails">("all");
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);

  const filteredProjects = activeTab === "all"
    ? PORTFOLIO_PROJECTS
    : PORTFOLIO_PROJECTS.filter((proj) => proj.category === activeTab);

  return (
    <section className="py-20 bg-brand-bg-light border-b border-gray-100" id="work">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Header Block & Tabs */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <span className="text-xs font-bold text-brand-red uppercase tracking-widest font-space inline-block mb-2">
              PORTFOLIO SHOWCASE
            </span>
            <h2 className="font-display text-4xl font-extrabold text-brand-blue tracking-tight">
              Selected Creator Showcases
            </h2>
            <p className="text-gray-400 font-sans text-sm mt-1 max-w-xl">
              Take a look at actual projects designed and edited by Dream Studio. Click on long-form or short-form items to watch retention-pacing edits live.
            </p>
          </div>

          {/* Filtering Tabs */}
          <div className="flex flex-wrap gap-2 select-none">
            {(["all", "long-form", "shorts", "thumbnails"] as const).map((tab) => {
              const labelMap = {
                all: "All Projects",
                "long-form": "Long Form Videos",
                shorts: "Shorts & Reels",
                thumbnails: "Thumbnail Art"
              };
              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-2.5 rounded-full text-xs font-bold font-space tracking-wide transition-all cursor-pointer ${
                    activeTab === tab 
                      ? "bg-brand-red text-[#0A0A0A] shadow-md shadow-brand-red/15 font-extrabold" 
                      : "bg-zinc-900 text-[#F5F5F5] border border-white/5 hover:border-[#CCFF00]"
                  }`}
                >
                  {labelMap[tab]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Visual Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProjects.map((proj) => {
            const hasVideo = !!proj.videoUrl;
            return (
              <div
                key={proj.id}
                className="bg-zinc-900 border border-white/5 rounded-3xl overflow-hidden shadow-md hover:shadow-xl hover:border-brand-red/20 transition-card group flex flex-col justify-between"
              >
                <div>
                  {/* Media Frame */}
                  <div className="relative aspect-video overflow-hidden bg-zinc-950 group-hover:scale-[1.01] transition-card">
                    <img
                      src={proj.bannerUrl}
                      alt={proj.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      loading="lazy"
                    />
                    
                    {/* Dark gradient blur over image */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80" />

                    {/* Category Label */}
                    <span className="absolute top-3 left-3 bg-[#CCFF00] text-[#0A0A0A] text-[10px] font-extrabold uppercase font-space tracking-wider px-2.5 py-1 rounded-full shadow-sm">
                      {proj.category.replace("-", " ")}
                    </span>

                    {/* CTR indicator overlay if thumbnail category */}
                    {proj.ctr && (
                      <span className="absolute bottom-3 left-3 bg-zinc-950/90 text-[#CCFF00] text-[11px] font-bold font-space px-2.5 py-1 rounded-full shadow-md inline-flex items-center gap-1.5 border border-white/5">
                        <TrendingUp className="w-3.5 h-3.5" /> {proj.ctr}
                      </span>
                    )}

                    {/* Live Play Trigger Overlay */}
                    {hasVideo && (
                      <button
                        onClick={() => setSelectedVideo(proj.videoUrl || null)}
                        className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity z-10 cursor-pointer"
                        aria-label="Play video"
                      >
                        <span className="w-14 h-14 rounded-full bg-brand-red text-[#0A0A0A] flex items-center justify-center shadow-lg transform scale-90 group-hover:scale-100 transition-all duration-300">
                          <Play className="w-6 h-6 fill-current ml-1" />
                        </span>
                      </button>
                    )}
                  </div>

                  {/* Body Info */}
                  <div className="p-5">
                    {/* Associated Creator */}
                    <div className="flex items-center gap-2 mb-3">
                      <img
                        src={proj.creator.avatar}
                        alt={proj.creator.name}
                        className="w-6 h-6 rounded-full object-cover ring-1 ring-white/10"
                      />
                      <div className="text-xs font-bold text-white">
                        {proj.creator.name}
                      </div>
                      <span className="text-[10px] text-slate-500 font-space font-semibold ml-auto">
                        {proj.creator.subscribers} Subs
                      </span>
                    </div>

                    <h3 className="font-display font-extrabold text-[#F5F5F5] text-sm leading-snug line-clamp-2 hover:text-brand-red transition-colors mb-2">
                      {proj.title}
                    </h3>
                  </div>
                </div>

                {/* Footer specs / status panel */}
                <div className="px-5 pb-5 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-slate-500 font-space font-semibold">
                  <span className="inline-flex items-center gap-1 text-[11px]">
                    <Eye className="w-3.5 h-3.5 text-slate-500" /> Retention Maximized
                  </span>
                  {proj.stats ? (
                    <span className="text-[#CCFF00] bg-brand-red/10 px-2 py-0.5 rounded text-[10px] border border-brand-red/10">
                      {proj.stats.split("•")[0]}
                    </span>
                  ) : (
                    <span className="text-brand-red font-bold">Designs Ready</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Video Player Modal Overlay */}
        {selectedVideo && (
          <div className="fixed inset-0 bg-[#0A0A0A]/95 backdrop-blur-md z-[100] flex items-center justify-center p-4">
            <div className="relative w-full max-w-4xl bg-black rounded-3xl overflow-hidden shadow-2xl border border-white/15">
              
              {/* Top Close Control */}
              <div className="absolute top-4 right-4 z-50">
                <button
                  onClick={() => setSelectedVideo(null)}
                  className="p-3 bg-black/60 hover:bg-black text-white hover:text-brand-red rounded-full transition-all cursor-pointer border border-white/10"
                  aria-label="Close player"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Embedded Player frame */}
              <div className="aspect-video w-full">
                <iframe
                  src={selectedVideo}
                  title="Portfolio video playback player"
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>

              {/* Stats Badge */}
              <div className="bg-zinc-950 p-5 text-white/90 text-sm flex items-center justify-between font-space border-t border-white/5">
                <span className="inline-flex items-center gap-2 text-xs uppercase tracking-wider font-bold">
                  <Award className="w-4 h-4 text-[#CCFF00]" /> Dream Studio Retention Cut
                </span>
                <span className="text-xs text-slate-400">
                  Pacing style: Interactive Captions overlay
                </span>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
