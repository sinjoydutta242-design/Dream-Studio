import React, { useState } from "react";
import { Zap, Menu, X, ChevronRight } from "lucide-react";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setMobileMenuOpen(false);
  };

  return (
    <header className="w-full z-50 bg-[#0A0A0A] border-b border-white/5" id="headerRef">
      {/* Hiring notification bar */}
      <div className="bg-brand-red text-[#0A0A0A] py-2 px-4 text-xs font-space font-medium text-center flex items-center justify-center gap-2">
        <span className="bg-black/10 px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider">Dream Studio</span>
        <span>We're looking for talented Thumbnail Designers & Video Editors!</span>
        <a 
          href="#get-started" 
          onClick={(e) => handleSmoothScroll(e, "get-started")}
          className="underline font-bold hover:opacity-80 inline-flex items-center gap-0.5 ml-1"
        >
          Apply Now <ChevronRight className="w-3 h-3" />
        </a>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-24 flex items-center justify-between relative">
        <a 
          href="#hero" 
          className="flex flex-col items-start gap-1 font-display text-brand-blue group"
        >
          <span className="text-2xl font-black tracking-tighter leading-none">
            DREAM STUDIO<span className="text-brand-red">.</span>
          </span>
          <span className="text-[9px] uppercase tracking-[0.3em] text-brand-red font-bold">
            Your Complete Solution
          </span>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-semibold font-display text-brand-blue/70">
          <a 
            href="#creators" 
            onClick={(e) => handleSmoothScroll(e, "creators")}
            className="hover:text-brand-blue transition-colors"
          >
            Partners
          </a>
          <a 
            href="#services" 
            onClick={(e) => handleSmoothScroll(e, "services")}
            className="hover:text-brand-blue transition-colors"
          >
            Services
          </a>
          <a 
            href="#work" 
            onClick={(e) => handleSmoothScroll(e, "work")}
            className="hover:text-brand-blue transition-colors"
          >
            Our Work
          </a>
          <a 
            href="#get-started" 
            onClick={(e) => handleSmoothScroll(e, "get-started")}
            className="hover:text-brand-blue transition-colors"
          >
            Get a Quote
          </a>
        </nav>

        {/* Call to Action Button */}
        <div className="hidden md:flex items-center gap-4">
          <a
            href="#get-started"
            onClick={(e) => handleSmoothScroll(e, "get-started")}
            className="bg-brand-red text-[#0A0A0A] font-display text-sm font-bold tracking-wide px-6 py-3 rounded-full hover:bg-brand-red-hover hover:scale-102 transition-all shadow-md shadow-brand-red/10 cursor-pointer inline-flex items-center gap-2"
          >
            Get in touch
            <ChevronRight className="w-4 h-4 text-[#0A0A0A]" />
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-brand-blue/80 hover:text-brand-blue"
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="absolute top-30 left-0 w-full bg-white z-40 border-b border-gray-200 shadow-xl p-6 md:hidden flex flex-col gap-4">
          <a
            href="#creators"
            onClick={(e) => handleSmoothScroll(e, "creators")}
            className="font-display font-bold text-lg text-brand-blue py-2 border-b border-gray-100"
          >
            Partners
          </a>
          <a
            href="#services"
            onClick={(e) => handleSmoothScroll(e, "services")}
            className="font-display font-bold text-lg text-brand-blue py-2 border-b border-gray-100"
          >
            Services
          </a>
          <a
            href="#work"
            onClick={(e) => handleSmoothScroll(e, "work")}
            className="font-display font-bold text-lg text-brand-blue py-2 border-b border-gray-100"
          >
            Our Work
          </a>
          <a
            href="#get-started"
            onClick={(e) => handleSmoothScroll(e, "get-started")}
            className="font-display font-bold text-lg text-brand-blue py-2"
          >
            Get in touch
          </a>
          <a
            href="#get-started"
            onClick={(e) => handleSmoothScroll(e, "get-started")}
            className="w-full text-center bg-brand-red text-[#0A0A0A] py-3 rounded-full font-bold shadow-lg mt-2"
          >
            Get Started Now
          </a>
        </div>
      )}
    </header>
  );
}
