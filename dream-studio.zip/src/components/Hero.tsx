import React from "react";
import { ChevronRight, ArrowUpRight, TrendingUp, Users, Play } from "lucide-react";
import { CREATORS } from "../data";

export default function Hero() {
  const handleSmoothScroll = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative overflow-hidden bg-white pt-8 pb-16 md:pb-24 border-b border-gray-100" id="hero">
      {/* Decorative blurred backdrops */}
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-brand-red/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-[350px] h-[350px] bg-brand-blue/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        {/* Left Typographic Column */}
        <div className="lg:col-span-6 flex flex-col items-start text-left">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-brand-bg-light border border-slate-200/80 mb-6">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-red opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-red"></span>
            </span>
            <span className="text-xs font-semibold font-space text-brand-blue/80 tracking-wide">
              PROUD PARTNER OF VALUE EDUCATOR (157K SUBS) & MORE
            </span>
          </div>

          <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-black tracking-tighter text-brand-blue leading-[0.95] mb-6">
            HELPING THE <br />
            <span className="text-stroke-neon font-black block">WORLD'S COOLEST</span> 
            CREATORS CREATE.
          </h1>

          <p className="text-gray-400 font-sans text-lg mb-8 leading-relaxed max-w-xl font-light">
            You love being in front of the camera. We do the heavy lifiting behind-the-scenes. Let our team of high-retention video editors and click-through artists nail your post-production, custom thumbnails, and channel growth, and watch your metrics skyrocket!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
            <button
              onClick={() => handleSmoothScroll("get-started")}
              className="bg-brand-red text-[#0A0A0A] text-base font-bold font-display px-8 py-4 rounded-full hover:bg-brand-red-hover hover:translate-y-[-2px] transition-all shadow-lg shadow-brand-red/20 inline-flex items-center justify-center gap-2 group cursor-pointer"
            >
              Get in Touch 
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => handleSmoothScroll("work")}
              className="bg-brand-bg-light text-brand-blue border border-white/10 hover:border-brand-red/30 text-base font-bold font-display px-8 py-4 rounded-full transition-all inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              Showcase of Work
            </button>
          </div>

          {/* Social Proof Stats Badges */}
          <div className="flex flex-wrap gap-8 mt-12 pt-8 border-t border-slate-100">
            <div>
              <div className="font-display font-black text-3xl text-brand-blue">150k+</div>
              <div className="text-xs font-semibold text-gray-400 font-space tracking-wider uppercase mt-1">Subs Served</div>
            </div>
            <div>
              <div className="font-display font-black text-3xl text-brand-blue">78%</div>
              <div className="text-xs font-semibold text-gray-400 font-space tracking-wider uppercase mt-1">CTR Peak Boost</div>
            </div>
            <div>
              <div className="font-display font-black text-3xl text-brand-blue">3.4M+</div>
              <div className="text-xs font-semibold text-gray-400 font-space tracking-wider uppercase mt-1">Total Impressions</div>
            </div>
          </div>
        </div>

        {/* Right Art Column - Stacked interactive creator cards simulating the custom mockup shapes */}
        <div className="lg:col-span-6 relative w-full h-[520px] sm:h-[580px] flex items-center justify-center select-none">
          {/* Decorative Background Shapes resembling the yellow, red and grey abstract blobs */}
          <div className="absolute top-1/4 left-10 w-[70%] h-[70%] rounded-full bg-yellow-400/25 blur-2xl -z-10 animate-pulse" />
          <div className="absolute bottom-12 right-10 w-[60%] h-[60%] rounded-full bg-brand-red/10 blur-3xl -z-10" />

          {/* Center Showcase Area */}
          <div className="relative w-full max-w-[480px] h-[480px]">
            {/* Creator Card 1: Value Educator */}
            <div className="absolute top-0 left-6 w-[280px] bg-zinc-900 p-5 rounded-3xl shadow-xl border border-white/5 hover:scale-105 hover:-translate-y-1 transition-card z-30">
              <div className="flex items-center gap-3 mb-3">
                <img 
                  src="https://yt3.googleusercontent.com/ytc/AIdro_knyy1IQqE-EaisDjw6RAc4FxXhK7t8lhvs4cYUQBOnRT0=s176-c-k-c0x00ffffff-no-rj-mo" 
                  alt="Value Educator avatar" 
                  className="w-12 h-12 rounded-full object-cover ring-2 ring-white/10"
                />
                <div>
                  <h3 className="font-display font-bold text-white text-sm">Value Educator</h3>
                  <p className="text-xs font-semibold text-[#CCFF00]">157K Subscribers</p>
                </div>
              </div>
              <p className="text-xs text-slate-300 line-clamp-2">
                &ldquo;Dream Studio revolutionized our education slide graphics and visual metaphors editing layout.&rdquo;
              </p>
              <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Educational Partner</span>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-brand-red bg-brand-red/5 px-2 py-0.5 rounded-full">
                  <ArrowUpRight className="w-3 h-3 text-[#CCFF00]" /> +15% CTR
                </span>
              </div>
            </div>

            {/* Creator Card 2: The Crafted Hour */}
            <div className="absolute top-1/3 right-0 w-[240px] bg-zinc-950 p-5 rounded-3xl shadow-2xl hover:scale-105 hover:-translate-y-1 border border-white/5 transition-card z-20">
              <div className="flex items-center gap-2 mb-3">
                <img 
                  src="https://yt3.googleusercontent.com/O24d0rFajDewo7qAZArH-KLgl-foKOwqz_93duDzOAdB6Ze7oO4YBb5lTV63lLU7W7jpKAYTRg=s160-c-k-c0x00ffffff-no-rj" 
                  alt="Avatar" 
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-white/10"
                />
                <div>
                  <h4 className="font-display font-bold text-white text-xs">The Crafted Hour</h4>
                  <p className="text-[10px] text-slate-400">432K Subs</p>
                </div>
              </div>
              <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                <span className="text-[9px] uppercase font-semibold text-slate-500">Total Views Gain</span>
                <p className="font-display font-black text-lg text-[#CCFF00]">+1.2M Views</p>
              </div>
            </div>

            {/* Creator Card 3: Generic Click Artist / Stat overlay */}
            <div className="absolute bottom-4 left-0 w-[220px] bg-zinc-900 p-5 rounded-2xl shadow-lg border border-white/5 hover:scale-105 transition-card z-20">
              <div className="flex items-center gap-2 mb-2">
                <span className="p-1 px-2 rounded-lg bg-brand-red/10 text-brand-red text-xs font-bold font-space inline-flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" /> Trend
                </span>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-space">Thumbnail CTR</span>
              </div>
              <p className="font-display font-black text-2xl text-white">14.8% CTR</p>
              <p className="text-[10px] font-medium text-[#CCFF00] mt-1">🎯 Up to 78% higher spike</p>
            </div>

            {/* Absolute Decorative Floating Items to mimic the original Praper vector shapes */}
            {/* Dynamic shape 1 */}
            <div className="absolute -top-12 right-20 bg-brand-red text-[#0A0A0A] font-bold px-3 py-1.5 rounded-full text-xs font-space rotate-12 shadow-md hidden md:block">
              🔥 100% Offline-free
            </div>
            
            {/* Dynamic shape 2 */}
            <div className="absolute bottom-20 right-6 bg-zinc-900 border border-white/5 p-3 rounded-2xl shadow-md flex items-center gap-2 hover:scale-105 transition-all cursor-pointer">
              <span className="w-8 h-8 rounded-full bg-brand-red text-[#0A0A0A] flex items-center justify-center">
                <Play className="w-4 h-4 fill-current ml-0.5" />
              </span>
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase">Retention Video</p>
                <p className="text-xs font-bold text-white">Watch demo cuts</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
