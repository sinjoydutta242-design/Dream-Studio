import React from "react";
import { Zap, Instagram, Linkedin, Heart, HelpCircle } from "lucide-react";

export default function Footer() {
  const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-[#0A0A0A] border-t border-white/5 pt-16 pb-12" id="footer">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Core Block */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-12 border-b border-white/5">
          
          {/* Logo & description Column */}
          <div className="md:col-span-5 flex flex-col items-start gap-4">
            <a 
              href="#hero" 
              onClick={(e) => handleSmoothScroll(e, "headerRef")}
              className="flex flex-col items-start gap-1 font-display text-brand-blue group"
            >
              <span className="text-xl font-black tracking-tighter leading-none">
                DREAM STUDIO<span className="text-brand-red">.</span>
              </span>
              <span className="text-[8px] uppercase tracking-[0.3em] text-brand-red font-bold">
                Your Complete Solution
              </span>
            </a>
            
            <p className="text-slate-400 font-sans text-xs leading-relaxed max-w-sm text-left">
              Dream Studio is a high-performance content creation and post-production graphic studio based in India. Proudly serving Value Educator with 154k subscribers and other professional channels to scale retention metric structures with full-stack layouts.
            </p>
          </div>

          {/* Useful Navigation Links Column */}
          <div className="md:col-span-3 text-left">
            <h4 className="font-display font-black text-sm text-white uppercase tracking-wider mb-4">
              Useful Links
            </h4>
            <ul className="space-y-2 text-xs font-semibold text-slate-500 font-space">
              <li>
                <a href="#creators" onClick={(e) => handleSmoothScroll(e, "creators")} className="hover:text-brand-red transition-colors">
                  Partners we serve
                </a>
              </li>
              <li>
                <a href="#services" onClick={(e) => handleSmoothScroll(e, "services")} className="hover:text-brand-red transition-colors">
                  Creative Services
                </a>
              </li>
              <li>
                <a href="#work" onClick={(e) => handleSmoothScroll(e, "work")} className="hover:text-brand-red transition-colors">
                  Work Showcase
                </a>
              </li>
              <li>
                <a href="#get-started" onClick={(e) => handleSmoothScroll(e, "get-started")} className="hover:text-brand-red transition-colors">
                  Contact Studio
                </a>
              </li>
            </ul>
          </div>

          {/* Social Presence Column */}
          <div className="md:col-span-4 text-left">
            <h4 className="font-display font-black text-sm text-white uppercase tracking-wider mb-4">
              Connect With Us
            </h4>
            
            <div className="flex gap-2">
              <a
                href="https://www.instagram.com/dreamstudio2026?igsh=MXRndDYwcnBpaW9hbw=="
                target="_blank"
                rel="noreferrer"
                className="p-3 bg-zinc-900 hover:bg-brand-red border border-white/5 hover:border-brand-red text-white hover:text-[#0A0A0A] rounded-full transition-all inline-block"
                aria-label="Instagram follow"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="p-3 bg-zinc-900 hover:bg-brand-red border border-white/5 hover:border-brand-red text-white hover:text-[#0A0A0A] rounded-full transition-all inline-block"
                aria-label="LinkedIn connect"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>

            <p className="text-[10px] text-gray-400 font-space font-medium leading-relaxed mt-4 max-w-xs">
              Direct and transparent pricing structures. Subscribe to secure your monthly upload pipeline slots today.
            </p>
          </div>

        </div>

        {/* Bottom Credits Block */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 font-space font-semibold gap-4">
          <p>© 2026 Dream Studio. Proudly powering professional channels.</p>
          <p className="flex items-center gap-1">
            Crafted with <Heart className="w-3.5 h-3.5 text-brand-red fill-current" /> for premium creators.
          </p>
        </div>

      </div>
    </footer>
  );
}
