import React from "react";
import { Video, Zap, Image, Mic, BarChart, CheckCircle } from "lucide-react";
import { SERVICES } from "../data";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Video: Video,
  Zap: Zap,
  Image: Image,
  Mic: Mic,
  BarChart: BarChart,
};

export default function ServicesList() {
  return (
    <section className="py-20 bg-white border-b border-gray-100" id="services">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-bold text-brand-red uppercase tracking-widest font-space inline-block mb-2">
            WHAT WE DO BEST
          </span>
          <h2 className="font-display text-4xl sm:text-5xl font-black text-brand-blue tracking-tight leading-tight">
            Comprehensive Editing & Design Solutions
          </h2>
          <div className="w-16 h-1 bg-brand-red mx-auto mt-4 rounded-full"></div>
          <p className="text-gray-400 font-sans text-sm mt-4">
            We handle the technical complexity of cutting, compositing, pacing, sound mixing, and graphic composition so you can focus entirely on planning great stories.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((srv) => {
            const IconComponent = ICON_MAP[srv.icon] || Video;
            return (
              <div
                key={srv.id}
                className="bg-zinc-900 border border-white/5 rounded-3xl p-8 hover:-translate-y-1 hover:border-brand-red/20 transition-card shadow-md hover:shadow-xl group relative overflow-hidden"
              >
                {/* Visual Accent */}
                <div className="absolute top-0 left-0 w-full h-[3px] bg-transparent group-hover:bg-brand-red transition-all" />

                <div className="flex items-start justify-between mb-6">
                  {/* Icon wrap */}
                  <div className="bg-zinc-950 text-brand-red group-hover:bg-brand-red group-hover:text-[#0A0A0A] p-4 rounded-2xl transition-all border border-white/5">
                    <IconComponent className="w-7 h-7" />
                  </div>
                  
                  {srv.ctrBoost && (
                    <span className="text-[10px] uppercase font-bold text-brand-red bg-brand-red/10 px-2.5 py-1 rounded-full font-space">
                      {srv.ctrBoost}
                    </span>
                  )}
                </div>

                <h3 className="font-display font-extrabold text-white text-xl mb-3 group-hover:text-brand-red transition-colors">
                  {srv.title}
                </h3>

                <p className="text-slate-400 font-sans text-xs leading-relaxed mb-6">
                  {srv.description}
                </p>

                {/* Foot Indicators */}
                <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs font-semibold text-white">
                  <span className="inline-flex items-center gap-1.5 text-slate-500 font-space font-medium text-[11px]">
                    <CheckCircle className="w-3.5 h-3.5 text-brand-red" /> High Impact Delivery
                  </span>
                  <span className="text-white">
                    Starts at <span className="font-bold text-brand-red">${srv.basePrice}</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
